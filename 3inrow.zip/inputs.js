const DEFAULTS = {
  ROW_SIZE: 4,
  COLORS_AMOUNT: 6,
  GAME_FIELD_SIZE: 300,
  DISTANCE_TO_SWAP: 40,
  DISTANCE_TO_EFFECT: 2,
  GRAVITY: 0.002,
  MOVES_TO_END: 4,
}

const COLORS = {
  GREEN: 0,
  RED: 1,
  BLUE: 2,
  YELLOW: 3,
  PINK: 4,
  CYAN: 5,
}

const DEFAULT_GAME_FIELD_1 = [
  [0, 1, 2, 3],
  [4, 5, 5, 3],
  [COLORS.BLUE, 4, 3, 1],
  [1, 5, 0, 3],
]

DEFAULTS.BOX_SIZE = DEFAULTS.GAME_FIELD_SIZE/DEFAULTS.ROW_SIZE;

const INIT_CONTROLS = {
  startBlock: null,
  zeroPoint: null,
};

const DIRECTIONS = {
  LEFT: 'LEFT',
  RIGHT: 'RIGHT',
  UP: 'UP',
  DOWN: 'DOWN',
}

window.game = (() => {
  let lib = null;
  let stage = null;
  let createjs = null;
  let field = [];
  let isControlsBlocked = false;
  let colorsOrder = []
  let currenMove = 0;

  let controls = {...INIT_CONTROLS};

  const init = (s, l, c) => {
    colorsOrder = [COLORS.CYAN, COLORS.CYAN, COLORS.BLUE, COLORS.RED, COLORS.CYAN, COLORS.RED, COLORS.YELLOW, COLORS.RED, COLORS.YELLOW, COLORS.PINK, COLORS.YELLOW, COLORS.PINK, COLORS.RED]
    lib = l;
    stage = s;
    createjs = c;
    generateField();
  }

  const generateField = () => {
    for(let i = 0; i < DEFAULTS.ROW_SIZE; i ++) {
      field.push([]);
      for(let j = 0; j < DEFAULTS.ROW_SIZE; j ++) {
        const gameBox = new lib.GameBox();
        field[i].push(gameBox);
        gameBox.isGameBox = true;
        // gameBox.color = getRandomColor();
        gameBox.color = DEFAULT_GAME_FIELD_1[i][j];
        gameBox.gotoAndStop(gameBox.color);
        const p = getPointByPosition(j, i);
        gameBox.x = p.x;
        gameBox.y = p.y;
        stage.addChild(gameBox);
        gameBox.position = {
          col: j,
          row: i,
        };
        addListenersToBox(gameBox);
      }
    }
  }


  const swapBoxes = (box1, box2, isBack = false, delay = 0) => {
    isControlsBlocked = true;
    field[box1.position.row][box1.position.col] = box2;
    field[box2.position.row][box2.position.col] = box1;
    const newBox1Position = {...box2.position};
    const newBox2Position = {...box1.position};
    box1.position = newBox1Position;
    box2.position = newBox2Position;
    const box1DefaultPoint = getPointByPosition(box1.position.col, box1.position.row);
    const box2DefaultPoint = getPointByPosition(box2.position.col, box2.position.row);
    const t1 = createjs.Tween.get(box1).wait(delay).to(box1DefaultPoint, 100, createjs.Ease.quadInOut);
    const t2 = createjs.Tween.get(box2).wait(delay).to(box2DefaultPoint, 100, createjs.Ease.quadInOut)
    const timeline = new createjs.Timeline([t1, t2]);

    timeline.on('complete', () => {
      const toDelete = getBoxesPositionsToDelete();
      if(!toDelete.length && !isBack) {
        swapBoxes(box1, box2, true, 200);
        return;
      }
      currenMove++
      deleteAndApplyGravity().then(() => {
        if(currenMove >= DEFAULTS.MOVES_TO_END) {
          removeAll()
          stage.gotoAndStop(1);
          return;
        }
        resetControls();
        isControlsBlocked = false;
      });
    });
  };

  removeAll = () => {
    field.forEach((row, i) => {
      row.forEach((box, j) => {
        if(box) {
          stage.removeChild(box);
        }
      });
    });
    field = [];
  }

  const fillEmptyBoxes = () => {
    console.log('fillEmptyBoxes');
    const promises = []
    field.forEach((row, i) => {
      row.forEach((box, j) => {
        if(!box) {
          console.log('no', i, j);
          const gameBox = new lib.GameBox();
          field[i][j] = gameBox;
          gameBox.isGameBox = true;
          //gameBox.color = getRandomColor();
          gameBox.color = colorsOrder.length ? colorsOrder.shift() : getRandomColor();
          gameBox.gotoAndStop(gameBox.color);
          const p = getPointByPosition(j, i);
          gameBox.x = p.x;
          gameBox.y = (-(DEFAULTS.ROW_SIZE - i)) * DEFAULTS.BOX_SIZE;
          stage.addChild(gameBox);
          gameBox.position = {
            col: j,
            row: i,
          };
          addListenersToBox(gameBox);
          const time = Math.sqrt(2*(Math.abs(gameBox.y - p.y))/DEFAULTS.GRAVITY);
          console.log('time', time, gameBox.y, p.y);
          const promise = new Promise((resolve) => {
            createjs.Tween.get(gameBox, { override: true })
              .to(p, time, createjs.Ease.quadIn)
              .to({...p, y: p.y - 10}, 100, createjs.Ease.quadOut)
              .to(p, 100, createjs.Ease.quadIn)
              .call(() => resolve());
          });
          promises.push(promise);
        }
      });
    });
    return Promise.all(promises);
  }

  const hasEmptyBoxes = () => {
    return field.flat().some(i => !i);
  }

  const deleteAndApplyGravity = () => {
    const toDelete = getBoxesPositionsToDelete();
    if(!toDelete.length) {
      return hasEmptyBoxes() ? fillEmptyBoxes().then(() => deleteAndApplyGravity()) : Promise.resolve();
    }
    deleteBoxesByPositions(toDelete);
    return applyGravity().then(() => deleteAndApplyGravity());
  }

  const applyGravity = () => {
    const promises = [];
    //reversed forEach;
    field.forEach((_, i) => {
      const row = field[field.length - 1 - i];
      row.forEach((_, j) => {
        const box = row[row.length - 1 - j];
        if(box && !box.touched) {
          box.touched = true;
          let distanceToFall = 0;
          let nextEmptyBox = getDownEmptyBlock(box.position);
          while(nextEmptyBox) {
            distanceToFall ++;
            nextEmptyBox = getDownEmptyBlock(nextEmptyBox);
          }
          if(distanceToFall) {
            console.log('Move', box?.position?.row, box?.position?.col, distanceToFall);
            const newPosition = {...box.position, row: box.position.row + distanceToFall};
            field[box.position.row][box.position.col] = null;
            field[newPosition.row][newPosition.col] = box;
            box.position = newPosition;
            const newCoords = getPointByPosition(newPosition.col, newPosition.row);
            const boxSize = DEFAULTS.GAME_FIELD_SIZE/DEFAULTS.ROW_SIZE;
            const time = Math.sqrt(2*(distanceToFall* boxSize)/DEFAULTS.GRAVITY);
            console.log('time', time);
            const promise = new Promise((resolve) => {
              createjs.Tween.get(box, { override: true })
                .to(newCoords, time, createjs.Ease.quadIn)
                .to({...newCoords, y: newCoords.y - 10}, 100, createjs.Ease.quadOut)
                .to(newCoords, 100, createjs.Ease.quadIn)
                .call(() => resolve());
            });
            promises.push(promise);
          }
        }
      });
    });
    cleanObjects();
    return Promise.all(promises);
  }

  const cleanObjects = () => {
    field.forEach((row) => {
      row.forEach((item) => {
        if(item) {
          item.touched = false;
        }
      });
    })
  }

  const deleteBoxesByPositions = (positions) => {
    positions.forEach((pos) => {
      const box = field[pos.row][pos.col];
      field[pos.row][pos.col] = null;
      stage.removeChild(box);
    })
  }

  const addListenersToBox = (gameBox) => {
    gameBox.on('pressmove', (evt) => {
      if(isControlsBlocked) return;
      if (evt.currentTarget.isGameBox && controls.startBlock) {
        const point = { x: evt.stageX, y: evt.stageY };
        const dir = getDirection(controls.zeroPoint, point);
        const box = controls.startBlock;
        const defaultPoint = getPointByPosition(box.position.col, box.position.row);
        const distX = (point.x - controls.zeroPoint.x);
        const distY = (point.y - controls.zeroPoint.y);


        if(Math.abs(distX) > DEFAULTS.DISTANCE_TO_SWAP || Math.abs(distY) > DEFAULTS.DISTANCE_TO_SWAP) {
          const boxToSwap = getBoxToSwap(box, dir);
          if(boxToSwap) {
            swapBoxes(box, boxToSwap);
          }
          return;
        }

        if(distX < DEFAULTS.DISTANCE_TO_EFFECT && distY < DEFAULTS.DISTANCE_TO_EFFECT) {
          return;
        }

        if(dir === DIRECTIONS.LEFT || dir === DIRECTIONS.RIGHT) {
          box.x = defaultPoint.x + distX;
          box.y = defaultPoint.y;
        }
        if(dir === DIRECTIONS.UP || dir === DIRECTIONS.DOWN) {
          box.x = defaultPoint.x;
          box.y = defaultPoint.y + distY;
        }
        stage.addChild(box);
      }
    });

    gameBox.on('mousedown', (evt) => {
      console.log('mousedown');
      if (evt.currentTarget.isGameBox && !controls.startBlock) {
        controls.startBlock = evt.currentTarget;
        controls.zeroPoint = { x: evt.stageX, y: evt.stageY };
        return;
      }
      if(isControlsBlocked) return;
      resetControls();
    });

    gameBox.on('pressup', (evt) => {
      if (isControlsBlocked) {
        resetControls();
        return;
      }
      if(controls.startBlock) {
        restorePositions()
      }
      resetControls();
    });
  }

  const getRightBlock = (box) => {
    return field[box.position.row]?.[box.position.col + 1] || null;
  }

  const getLeftBlock = (box) => {
    return field[box.position.row]?.[box.position.col - 1] || null;
  }

  const getUpBlock = (box) => {
    return field[box.position.row - 1]?.[box.position.col] || null;
  }

  const getDownBlock = (box) => {
    return field[box.position.row + 1]?.[box.position.col] || null;
  }

  const getDownEmptyBlock = (position) => {
    if(position.row + 1 >= DEFAULTS.ROW_SIZE) {
      return null;
    }
    if(field[position.row + 1]?.[position.col]) {
      return null;
    }
    return {
      row: position.row + 1,
      col: position.col,
    }
  }

  const getBoxToSwap = (box, dir) => {
    if(!box) return null;
    if (dir === DIRECTIONS.RIGHT) {
      return getRightBlock(box);
    }
    if (dir === DIRECTIONS.LEFT) {
      return getLeftBlock(box)
    }
    if (dir === DIRECTIONS.UP) {
      return getUpBlock(box);
    }
    if (dir === DIRECTIONS.DOWN) {
      return getDownBlock(box);
    }
    return null;
  }

  const getPointByPosition = (col, row) => {
    const point = {};
    point.x = (DEFAULTS.GAME_FIELD_SIZE/DEFAULTS.ROW_SIZE)*col;
    point.y = (DEFAULTS.GAME_FIELD_SIZE/DEFAULTS.ROW_SIZE)*row;
    return point;
  }

  const getDirection = (p1, p2) => {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;

    if (Math.abs(dx) > Math.abs(dy)) {
      return dx > 0 ? DIRECTIONS.RIGHT : DIRECTIONS.LEFT;
    } else {
      return dy > 0 ? DIRECTIONS.DOWN : DIRECTIONS.UP;
    }
  }

  const getDistance = (p1, p2) => {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    return Math.sqrt(dx * dx + dy * dy);
  }

  const restorePositions = () => {
    field.forEach((row) => {
      row.forEach((item) => {
        if(!item) return;
        const pos = getPointByPosition(item.position.col, item.position.row);
        createjs.Tween.get(item).to(pos, 100, createjs.Ease.quadInOut);
      });
    })
  }

  const getBoxesPositionsToDelete = () => {
    const posToRemove = [];
    field.forEach((row) => {
      row.forEach((box) => {
          if(has3InRow(box)) {
            posToRemove.push(box.position);
          }
      });
    });
    return posToRemove;
  }


  const has3InRow = (box) => {
    const countHorizontal = checkSameColorsCountInDirection(box, DIRECTIONS.LEFT) + checkSameColorsCountInDirection(box, DIRECTIONS.RIGHT);
    const countVertical = checkSameColorsCountInDirection(box, DIRECTIONS.UP) + checkSameColorsCountInDirection(box, DIRECTIONS.DOWN);
    return countHorizontal >= 2 || countVertical >= 2;
  }

  const checkSameColorsCountInDirection = (box, dir) => {
    const color = box?.color;
    let nextBox = getBoxToSwap(box, dir);
    let count = 0;
    while (nextBox && nextBox?.color === color) {
      count ++;
      nextBox = getBoxToSwap(nextBox, dir);
    }
    return count;
  }

  const resetControls = () => {
    controls = {...INIT_CONTROLS};
  }

  const getRandomColor = () => {
    return Math.floor(Math.random() * DEFAULTS.COLORS_AMOUNT)
  }

  return { init };
})();
